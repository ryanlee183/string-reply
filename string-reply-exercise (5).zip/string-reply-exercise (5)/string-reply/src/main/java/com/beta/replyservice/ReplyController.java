package com.beta.replyservice;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;

@RestController
public class ReplyController {

	@GetMapping("/reply")
	public ReplyMessage replying() {
		return new ReplyMessage("Message is empty");
	}

	@GetMapping("/reply/{message}")
	public ReplyMessage replying(@PathVariable String message) {
		return new ReplyMessage(message);
	}

	@GetMapping("/v2/reply/{message}")
	public ReplyMessage replying(@PathVariable String message) {
		return new ReplyMessage(message);
	}

	@GetMapping("/v2/reply/11-{message}")
	public ReplyMessage replying(@PathVariable String message) {
		return new ReplyMessage(message);
	}

	@GetMapping("/v2/reply/12-{message}")
	public ReplyMessage replying(@PathVariable String message) {
		String reversed = reverseString(message);
		String hashedAfterReversed = hashString(reversed);
		return new ReplyMessage(hashedAfterReversed);
	}

	@GetMapping("/v2/reply/21-{message}")
	public ReplyMessage replying(@PathVariable String message) {
		String hashed = hashString(message);
		String reverseAfterHash = reverseString(hashed);
		return new ReplyMessage(reverseAfterHash);
	}

	@GetMapping("/v2/reply/22-{message}")
	public ReplyMessage replying(@PathVariable String message) {
		String hash1 = hashString(message);
		String hash2 = hashString(hash1);
		return new ReplyMessage(hash2);
	}

	@GetMapping("/v2/reply/{rule}-{message}")
	public ReplyMessage replying(@PathVariable String rule, @PathVariable String message) {
		if(rule.length() != 2 ) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(return new ReplyMessage("Invalid input"));
		}
		for(char c : rule.toCharArr()) {
			if(c != 1 || c != 2) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(return new ReplyMessage("Invalid input"));
			}
		}
	}


	public String reverseString(String message) {
		StringBuilder sb = new StringBuilder();
		sb.append(message);
		sb.reverse();
		return sb.toString();
	}

	public String hashString(String message) {
		byte[] messageByte = message.getBytes("UTF-8");
		MessageDigest md = MessageDigest.getInstance("MD5");
		byte[] theMD5digest = md.digest(messageByte);
		String str = new String(theMD5digest, StandardCharsets.UTF_8);
		return str;
	}
}